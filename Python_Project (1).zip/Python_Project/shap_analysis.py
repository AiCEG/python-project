import joblib
import pandas as pd
import subprocess
import sys

# Funktion, um ein Modul zu installieren
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Installation von shap
try:
    import shap
except ImportError:
    print("shap ist nicht installiert. Es wird jetzt installiert...")
    install("shap")
    import shap

# Neues Modell und Daten laden
rf_model = joblib.load('random_forest_new.pkl')
X = pd.read_csv('X_prepared.csv')

# SHAP-Explainer erstellen
explainer = shap.Explainer(rf_model, X)
shap_values = explainer(X)

# Ergebnisse visualisieren
shap.summary_plot(shap_values, X)