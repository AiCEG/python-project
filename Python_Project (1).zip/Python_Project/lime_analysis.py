import joblib
import pandas as pd
from lime.lime_tabular import LimeTabularExplainer

# Neues Modell und Daten laden
rf_model = joblib.load('random_forest_new.pkl')
X = pd.read_csv('X_prepared.csv')

# LIME-Explainer erstellen
lime_explainer = LimeTabularExplainer(X.values, feature_names=X.columns, mode='regression')

# Beispiel-Instanz erklären
exp = lime_explainer.explain_instance(X.iloc[0].values, rf_model.predict, num_features=5)
exp.show_in_notebook()