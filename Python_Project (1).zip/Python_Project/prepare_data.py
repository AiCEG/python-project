import pandas as pd
from sklearn.model_selection import train_test_split

def load_and_prepare_data():
    # Excel-Dateien laden
    df_bildungsausgaben = pd.read_excel('Bildungsausgaben_Schweiz.xlsx')
    df_bip_einkommen = pd.read_excel('BIP nach Einkommensart.xlsx')
    df_studierende_mint = pd.read_excel('T10 Studierende nach Studientstufe und MINT Fach seit 2014.xlsx')

    # Debug: Spaltennamen anzeigen
    print("Spalten von df_bildungsausgaben:", df_bildungsausgaben.columns)
    print("Spalten von df_bip_einkommen:", df_bip_einkommen.columns)
    print("Spalten von df_studierende_mint:", df_studierende_mint.columns)

    # Spalten nur für diesen Code umbenennen
    df_bildungsausgaben = df_bildungsausgaben.rename(columns={'jahr': 'Jahr', 'schweiz': 'Bildungsausgaben'})
    df_bip_einkommen = df_bip_einkommen.rename(columns={'Gliederung': 'Jahr', 'Bruttoinlandprodukt': 'BIP'})
    df_studierende_mint = df_studierende_mint.rename(columns={'Jahr': 'Jahr', 'Mint-Fächer': 'MINT-Studierende'})

    # Verarbeitung der Daten (Beispiel: Auswahl relevanter Spalten)
    df_bildungsausgaben = df_bildungsausgaben[['Jahr', 'Bildungsausgaben']]
    df_bip_einkommen = df_bip_einkommen[['Jahr', 'BIP']]
    df_studierende_mint = df_studierende_mint[['Jahr', 'MINT-Studierende']]

    # Zusammenführen der Daten
    df_combined = pd.merge(df_bildungsausgaben, df_bip_einkommen, on='Jahr')
    df_combined = pd.merge(df_combined, df_studierende_mint, on='Jahr')

    # Features (X) und Zielvariable (y) definieren
    X = df_combined[['Bildungsausgaben', 'BIP', 'MINT-Studierende']]
    y = df_combined['Bildungsausgaben']  # Beispielzielvariable (kann angepasst werden)

    # Daten speichern
    X.to_csv('X_prepared.csv', index=False)
    y.to_csv('y_prepared.csv', index=False)

    print("Daten erfolgreich vorbereitet und gespeichert!")
    return X, y

if __name__ == "__main__":
    load_and_prepare_data()