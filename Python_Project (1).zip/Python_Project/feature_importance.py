import joblib
import pandas as pd
import matplotlib.pyplot as plt

# Neues Modell und Daten laden
rf_model = joblib.load('random_forest_new.pkl')
X = pd.read_csv('X_prepared.csv')

# Feature Importances visualisieren
importances = rf_model.feature_importances_
feature_names = X.columns

plt.figure(figsize=(10, 6))
plt.barh(feature_names, importances)
plt.xlabel('Importance')
plt.ylabel('Features')
plt.title('Feature Importance (Random Forest)')
plt.show()